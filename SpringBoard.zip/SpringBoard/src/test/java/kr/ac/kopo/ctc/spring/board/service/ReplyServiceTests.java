package kr.ac.kopo.ctc.spring.board.service;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import kr.ac.kopo.ctc.spring.board.DTO.ReplyDTO;

@SpringBootTest
public class ReplyServiceTests {
	
	@Autowired
	private ReplyService replyService;
	
	@Test
	public void getList() {
		
		//게시글의 번호가 88번인 댓글리스트
		Long bno = 88L;
		
		List<ReplyDTO> replyDTOList = replyService.getList(bno);
		
		replyDTOList.forEach(replyDTO -> System.out.println(replyDTO));	
		
	}
	

}
