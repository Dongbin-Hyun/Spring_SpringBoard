package kr.ac.kopo.ctc.spring.board.repositorytest;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import kr.ac.kopo.ctc.spring.board.domain.Board;
import kr.ac.kopo.ctc.spring.board.domain.Member;
import kr.ac.kopo.ctc.spring.board.repository.BoardRepository;

@SpringBootTest
public class BoardRepositoryTests {
	
	@Autowired
	BoardRepository boardRepository;
	
	//@Test
	public void insertBoard() {
		
		System.out.println("Start");
		
		IntStream.rangeClosed(1, 100).forEach(i -> {
			Member member = Member.builder().email("user" + i + "@naver.com").build();
			Board board = Board.builder()
							.title("게시판 제목" + i)
							.content("게시판 내용" +i)
							.writer(member)
							.build();
			
			boardRepository.save(board);
			
		});
		
		System.out.println("End");
	}
	
	//@Test
	public void readWithMember() {
		
		Object result = boardRepository.getBoardWithWriter(100L);
		
		Object[] arr = (Object[]) result;
		
		System.out.println("Start");
		System.out.println(Arrays.toString(arr));
		System.out.println("End");
	}
	
	//@Test
	public void getBoardWithReply() {
		
		System.out.println("Start");
		List<Object[]> result = boardRepository.getBoardWithReply(100L);
		
		//100번째 게시판에 속한 댓글을 보여줌
		for (Object[] arr : result) {
			System.out.println(Arrays.toString(arr));
		}
		
		System.out.println("End");
	}
	
	//@Test
	public void withReplyCount() {
		Pageable pageable = PageRequest.of(0, 10, Sort.by("bno").descending());
		Page<Object[]> result = boardRepository.getBoardWithReplyCount(pageable);
		result.get().forEach(row ->  {
			Object[] arr = (Object[]) row;
			System.out.println(Arrays.toString(arr));
		});
	}
	
	//@Test
	public void read3() {
		Object result = boardRepository.getBoardByBno(100L);
		
		Object[] arr = (Object[])result;
		
		System.out.println(Arrays.toString(arr));
	}
	
	//@Test
	public void search1() {
		boardRepository.search1();
	}
	
	@Test
	public void searchPage() {
		Pageable pageable = PageRequest.of(0, 10, Sort.by("bno").descending().and(Sort.by("title").ascending()));
		
		//제목(t)으로 "1"이라는 단어가 있는 데이터를 검색
		Page<Object[]> result = boardRepository.searchPage("t", "2", pageable);
	}
	
	

}
