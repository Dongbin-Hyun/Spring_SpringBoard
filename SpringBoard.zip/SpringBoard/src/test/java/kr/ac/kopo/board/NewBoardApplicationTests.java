package kr.ac.kopo.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
