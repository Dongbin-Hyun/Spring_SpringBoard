package kr.ac.kopo.ctc.spring.board.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import kr.ac.kopo.ctc.spring.board.domain.Board;
import kr.ac.kopo.ctc.spring.board.DTO.*;

@SpringBootTest
public class BoardServiceTests {
	
	@Autowired
	private BoardService boardService;
	
	//@Test
	public void create() {
		
		BoardDTO bdto = BoardDTO.builder()
						.title("NEW 게시글 작성 연습 제목1")
						.content("NEW 게시판 내용 작성1")
						.writerEmail("user1@naver.com")
						.build();
		
		Long bno = boardService.create(bdto);
						
		
	}
	
	//@Test
	public void delete() {
		
		Long bno = 4L;
		
		boardService.deleteWithReplies(bno);
	}
	
	//@Test
	public void get() {
		
		Long bno = 44L;
		
		BoardDTO boardDTO = boardService.get(bno);
		
		System.out.println(boardDTO);
		
	}
	
	@Test
	public void modify() {
		
		BoardDTO boardDTO = BoardDTO.builder()
						.bno(4L)
						.title("수정했음! 확인!")
						.content("내용을 다시 변경했습니다.")
						.build();
		
		boardService.modify(boardDTO);
		
	}
	
	//@Test
	public void list() {
		
		PageRequestDTO pageRequestDTO = new PageRequestDTO();
		
		PageResultDTO<BoardDTO, Object[]> result = boardService.getList(pageRequestDTO);
		
		System.out.println("List 시작");
		
		for (BoardDTO boardDTO : result.getDtoList()) {
			System.out.println(boardDTO);
		}
		
		
		System.out.println("List 종료");
	}
	
	
	
	
}
