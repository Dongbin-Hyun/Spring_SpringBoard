package kr.ac.kopo.ctc.spring.board.repositorytest;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import kr.ac.kopo.ctc.spring.board.domain.Board;
import kr.ac.kopo.ctc.spring.board.domain.Reply;
import kr.ac.kopo.ctc.spring.board.repository.ReplyRepository;

@SpringBootTest
public class ReplyRepositoryTests {
	
	@Autowired
	ReplyRepository replyRepository;
	
	//@Test
	public void insertReply() {
		
		System.out.println("Start");
		
		IntStream.rangeClosed(1, 300).forEach(i -> {
			long bno = (long)(Math.random()*100) + 1;
			
			Board board = Board.builder().bno(bno).build();
			
			Reply reply = Reply.builder()
							.text("댓글입니다" + i)
							.replyer("댓글러" + i)
							.board(board)
							.build();
			
			replyRepository.save(reply);
			
		});
		
		System.out.println("End");
		
		
	}
	
	@Test
	public void listByBoard() {
		
		//게시글 97번의 댓글 정보
		List<Reply> replyList = replyRepository.getRepliesByBoardOrderByRno(Board.builder().bno(97L).build());
		
		replyList.forEach(reply -> System.out.println(reply));
	}
	


}
