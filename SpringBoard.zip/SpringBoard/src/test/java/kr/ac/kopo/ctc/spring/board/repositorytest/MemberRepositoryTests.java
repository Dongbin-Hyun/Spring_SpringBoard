package kr.ac.kopo.ctc.spring.board.repositorytest;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import kr.ac.kopo.ctc.spring.board.domain.Member;
import kr.ac.kopo.ctc.spring.board.repository.MemberRepository;

@SpringBootTest
public class MemberRepositoryTests {

	@Autowired 
	MemberRepository memberRepository;
	
	@Test
	public void insertMembers() {
		
		System.out.println("Start");
		
		IntStream.rangeClosed(1, 100).forEach(i -> {
			Member member = Member.builder()
							.email("user" + i + "@naver.com")
							.password("1234")
							.name("이름" + i)
							.build();
			
			memberRepository.save(member);
		});
		
		System.out.println("End");
		
	}
	
	

}
