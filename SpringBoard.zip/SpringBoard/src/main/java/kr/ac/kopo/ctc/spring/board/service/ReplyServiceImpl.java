package kr.ac.kopo.ctc.spring.board.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import kr.ac.kopo.ctc.spring.board.DTO.ReplyDTO;
import kr.ac.kopo.ctc.spring.board.domain.Board;
import kr.ac.kopo.ctc.spring.board.domain.Reply;
import kr.ac.kopo.ctc.spring.board.repository.ReplyRepository;
import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class ReplyServiceImpl implements ReplyService {
	
	private final ReplyRepository replyRepository;

	@Override
	public Long create(ReplyDTO replyDTO) {
		
		Reply reply = dtoToEntity(replyDTO);
		
		replyRepository.save(reply);
		
		return reply.getRno();
	}

	@Override
	public List<ReplyDTO> getList(Long bno) {
		
		List<Reply> result = replyRepository.getRepliesByBoardOrderByRno(Board.builder().bno(bno).build());
		
		return result.stream().map(reply -> entityToDTO(reply)).collect(Collectors.toList());
	}

	@Override
	public void modify(ReplyDTO replyDTO) {
		
		Reply reply = dtoToEntity(replyDTO);
		
		replyRepository.save(reply);
		
	}

	@Override
	public void delete(Long rno) {
		
		replyRepository.deleteById(rno);
		
	}
	

}
