package kr.ac.kopo.ctc.spring.board.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import kr.ac.kopo.ctc.spring.board.domain.*;

public interface MemberRepository extends JpaRepository<Member, String>{

}
