package kr.ac.kopo.ctc.spring.board.repository.search;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import kr.ac.kopo.ctc.spring.board.domain.Board;

public interface SearchBoardRepository {
	
	//Repository를 확장
	Board search1();
	
	//JPQLQuery로 Page<Object[]>처리
	//type:검색타입, keyword:검색어 pageable:페이지정보
	Page<Object[]> searchPage(String type, String keyword, Pageable pageable);

}
