package kr.ac.kopo.ctc.spring.board.service;

import java.util.List;

import kr.ac.kopo.ctc.spring.board.DTO.ReplyDTO;
import kr.ac.kopo.ctc.spring.board.domain.Board;
import kr.ac.kopo.ctc.spring.board.domain.Reply;

public interface ReplyService {
	
	Long create(ReplyDTO replyDTO);
	
	List<ReplyDTO> getList(Long bno);
	
	void modify(ReplyDTO replyDTO);
	
	void delete(Long rno);
	
	//DTO -> Entity
	default Reply dtoToEntity(ReplyDTO replyDTO) {
		
		Board board = Board.builder().bno(replyDTO.getBno()).build();
		
		Reply reply = Reply.builder()
						.rno(replyDTO.getRno())
						.text(replyDTO.getText())
						.replyer(replyDTO.getReplyer())
						.board(board)
						.build();
		
		return reply;	
	}
	
	
	//Entity -> DTO
	default ReplyDTO entityToDTO(Reply reply) {
		
		ReplyDTO replyDTO = ReplyDTO.builder()
								.rno(reply.getRno())
								.text(reply.getText())
								.replyer(reply.getReplyer())
								.regDate(reply.getRegDate())
								.modDate(reply.getModDate())
								.build();
		
		return replyDTO;
	}
	

}
