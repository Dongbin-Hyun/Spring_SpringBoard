package kr.ac.kopo.ctc.spring.board.repository.search;



import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport;

import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Order;
import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.PathBuilder;
import com.querydsl.jpa.JPQLQuery;

import kr.ac.kopo.ctc.spring.board.domain.Board;
import kr.ac.kopo.ctc.spring.board.domain.QBoard;
import kr.ac.kopo.ctc.spring.board.domain.QMember;
import kr.ac.kopo.ctc.spring.board.domain.QReply;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class SearchBoardRepositoryImpl 
				extends QuerydslRepositorySupport implements SearchBoardRepository {
	
	
	public SearchBoardRepositoryImpl() {
		
		super(Board.class);
		
	}
	
	@Override
	public Board search1() {
		
		log.info("search1....");
		
		QBoard board = QBoard.board;
		QReply reply = QReply.reply;
		QMember member = QMember.member;
			
		
		JPQLQuery<Board> jpqlQuery = from(board);
		jpqlQuery.leftJoin(reply).on(reply.board().eq(board));
		jpqlQuery.leftJoin(member).on(board.writer().eq(member));
		
		//Tuple객체 정해진 엔티티 객체가 아니라 각각의 데이터를 추출하는 경우 Tuple이라는 객체를 이용
		//board엔티티, member.email, reply.count() 묶
		JPQLQuery<Tuple> tuple = jpqlQuery.select(board, member.email, reply.count());
		tuple.groupBy(board);
		
		//jpqlQuery.select(board).where(board.bno.eq(1L));
		
		log.info("-------------start------------------");
		log.info(tuple);
		log.info("-------------end------------------");
		
		List<Tuple> result = tuple.fetch();
		
		log.info(result);
		
		//List<Board> result = jpqlQuery.fetch();
		
		return null;
	}

	@Override
	public Page<Object[]> searchPage(String type, String keyword, Pageable pageable) {
		
		log.info("searchPage.....");
		
		QBoard board = QBoard.board;
		QReply reply = QReply.reply;
		QMember member = QMember.member;
			
		
		JPQLQuery<Board> jpqlQuery = from(board);
		jpqlQuery.leftJoin(reply).on(reply.board().eq(board));
		jpqlQuery.leftJoin(member).on(board.writer().eq(member));
		
		JPQLQuery<Tuple> tuple = jpqlQuery.select(board, member, reply.count());
		
		BooleanBuilder booleanBuilder = new BooleanBuilder();
		
		//bno > 0 조건만 생성
		BooleanExpression expression = board.bno.gt(0L);
		
		booleanBuilder.and(expression);
		
		if (type != null) {
			String[] typeArr = type.split("");
			
			//검색 조건 생성
			BooleanBuilder conditionBuilder = new BooleanBuilder();
			
			for (String t:typeArr) {
				
				switch (t) {
					case "t":
						conditionBuilder.or(board.title.contains(keyword));
						break;
						
					case "w":
						conditionBuilder.or(member.name.contains(keyword));
						break;
						
					case "c":
						conditionBuilder.or(board.content.contains(keyword));
						break;	
				}
			}
		
			booleanBuilder.and(conditionBuilder);
			
		}
		
		tuple.where(booleanBuilder);
		
		//sort, count 처리
		Sort sort = pageable.getSort();
		
		sort.stream().forEach(order -> {
			Order direction = order.isAscending()? Order.ASC: Order.DESC;
			
			String prop = order.getProperty();
			
			PathBuilder orderByExpression = new PathBuilder(Board.class, "board");
			
			tuple.orderBy(new OrderSpecifier(direction, orderByExpression.get(prop)));
		});
			
		tuple.groupBy(board);
		
		//page 처리
		tuple.offset(pageable.getOffset());
		tuple.limit(pageable.getPageSize());
			
		List<Tuple> result = tuple.fetch();
		
		log.info(result);
		
		long count = tuple.fetchCount();
		
		log.info("Count : " + count);
	
			
		return new PageImpl<Object[]>(result.stream().map(t -> t.toArray()).collect(Collectors.toList()), pageable, count);
	}

}
