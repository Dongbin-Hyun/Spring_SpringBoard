package kr.ac.kopo.ctc.spring.board.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.ac.kopo.ctc.spring.board.DTO.BoardDTO;
import kr.ac.kopo.ctc.spring.board.DTO.PageRequestDTO;
import kr.ac.kopo.ctc.spring.board.service.BoardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller
@RequestMapping({"/board/"})
@Log4j2
@RequiredArgsConstructor
public class BoardController {
	
	
	
	//자동주입을 위해 final
	private final BoardService boardService;
	
	//목록
	@GetMapping("/list")
	public void list(PageRequestDTO pageRequestDTO, Model model) {
		
		log.info("list..." + pageRequestDTO);
		
		model.addAttribute("result", boardService.getList(pageRequestDTO));
		
	}
	
	//등록
	@GetMapping("/create")
	public void create() {
		
		log.info("create get...");
		
	}
	
	@PostMapping("/create")
	public String createPost(BoardDTO dto, RedirectAttributes redirectAttributes) {
		
		log.info("dto..." + dto);
		
		//새로 추가된 entity 번호
		Long bno = boardService.create(dto);
		
		log.info("BNO..." + bno);
		
		redirectAttributes.addFlashAttribute("msg", bno);
		
		return "redirect:/board/list";
		
	}
	
	//수정작업을 위한 화면은 조회와 동일하므로 read() 메서드를 그대로 이용
	//@ModelAttribute에서 선언된 이름은 html에서 사용됨
	@GetMapping({"/read", "/modify" })
	public void read(@ModelAttribute("pageRequestDTO") PageRequestDTO pageRequestDTO, Long bno, Model model) {
	//GET방식으로 bno를 받아서 Model에 BoardDTO객체를 받아서 전달
	//나중에 다시 목록 페이지로 돌아가는 데이터를 같이 저장하기 위해 PageRequestDTO를 파라미터로
	//받아 같이 사용
		log.info("bno: " + bno);
		
		BoardDTO boardDTO = boardService.get(bno);
		
		log.info(boardDTO);
		
		model.addAttribute("dto", boardDTO);
		
		
	}
	
	//POST방식의 처리는 boardService의 modify()와 remove() 호출해서 처리
	@PostMapping("/remove")
	public String remove(long bno, RedirectAttributes redirectAttributes) {
		
		log.info("bno" + bno);
		
		boardService.deleteWithReplies(bno);
		
		redirectAttributes.addFlashAttribute("msg", bno);
		
		return "redirect:/board/list";
		
	}
	
	
	@PostMapping("/modify")
	//@ModelAttribute에서 선언된 이름은 html에서 사용됨
	public String modify(BoardDTO dto, @ModelAttribute("pageRequestDTO") PageRequestDTO pageRequestDTO,
					RedirectAttributes redirectAttributes) {
		
		log.info("post modify.......");
		
		log.info("dto: " + dto);
		
		boardService.modify(dto);
		
		redirectAttributes.addAttribute("page", pageRequestDTO.getPage());
		redirectAttributes.addAttribute("type", pageRequestDTO.getType());
		redirectAttributes.addAttribute("keyword", pageRequestDTO.getKeyword());
		
		redirectAttributes.addAttribute("bno", dto.getBno());
		
		return "redirect:/board/read";
		
		
	}
	
	
	
	
	

}
