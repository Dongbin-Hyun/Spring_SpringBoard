package kr.ac.kopo.ctc.spring.board.DTO;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import lombok.Data;

@Data
public class PageResultDTO <DTO, EN> {
	//제너릭 타입을 이용
	//다양한 곳에서 사용가능
	
	//DTO리스트
	private List<DTO> dtoList;
	
	//총 페이지 번호
	private int totalPage;
	
	//현재 페이지 번호
	private int page;
	
	//목록 사이즈
	private int size;
	
	//시작 페이지 번호, 끝 페이지 번호
	private int start;
	private int end;
	
	//이전, 다음
	private boolean prev;
	private boolean next;
	
	//페이지 번호 목록
	private List<Integer> pageList;
	
	public PageResultDTO(Page<EN> result, Function<EN, DTO> fn) {
		
		dtoList = result.stream().map(fn).collect(Collectors.toList());
		
		totalPage = result.getTotalPages();
		
		makePageList(result.getPageable());
	}

	private void makePageList(Pageable pageable) {
		
		this.page = pageable.getPageNumber() + 1;
		//0부터 시작하므로 1 추가
		//JPA는 0부터 시작하지만 우리는 1페이지부터 시작
		
		this.size = pageable.getPageSize();
		//페이지 사이즈
		
		//temp end page
		int tempEnd = (int)(Math.ceil(page / 10.0)) * 10;
		
		start = tempEnd - 9;
		
		prev = start > 1;
		
		end = totalPage > tempEnd ? tempEnd: totalPage;
		
		next = totalPage > tempEnd;
		
		pageList = IntStream.rangeClosed(start, end).boxed().collect(Collectors.toList());
						
		
	}
	
	
	
}
