package kr.ac.kopo.ctc.spring.board.service;

import java.util.function.Function;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import kr.ac.kopo.ctc.spring.board.DTO.BoardDTO;
import kr.ac.kopo.ctc.spring.board.DTO.PageRequestDTO;
import kr.ac.kopo.ctc.spring.board.DTO.PageResultDTO;
import kr.ac.kopo.ctc.spring.board.domain.Board;
import kr.ac.kopo.ctc.spring.board.domain.Member;
import kr.ac.kopo.ctc.spring.board.repository.BoardRepository;
import kr.ac.kopo.ctc.spring.board.repository.ReplyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@RequiredArgsConstructor
@Log4j2
public class BoardServiceImpl implements BoardService {
	
	//자동주입 final
	private final BoardRepository boardRepository;
	
	//자동주입 final
	private final ReplyRepository replyRepository;
	
	@Override
	public PageResultDTO<BoardDTO, Object[]> getList(PageRequestDTO pageRequestDTO) {
		//entityToDTO()를 이용해서 PageResultDTO 객체를 구성
		
		log.info(pageRequestDTO);
		
		Function<Object[], BoardDTO> fn = (en -> entityToDTO((Board)en[0], 
						(Member)en[1], (Long)en[2]));
		
//		Page<Object[]> result = boardRepository.getBoardWithReplyCount(
//						pageRequestDTO.getPageable(Sort.by("bno").descending()));
		
		Page<Object[]> result = boardRepository.searchPage(pageRequestDTO.getType(), pageRequestDTO.getKeyword(), pageRequestDTO.getPageable(Sort.by("bno").descending()));
		
		return new PageResultDTO<>(result, fn);
		
	}

	@Override
	public Long create(BoardDTO dto) {
		//게시글 작성
		
		log.info(dto);
		
		Board board = dtoToEntity(dto);
		
		boardRepository.save(board);
		
		return board.getBno();
	}

	
	
	@Override
	public BoardDTO get(Long bno) {
		
		Object result = boardRepository.getBoardByBno(bno);
		
		Object[] arr = (Object[]) result;
		
		return entityToDTO((Board)arr[0], (Member)arr[1], (Long)arr[2]);
				
	}
	
	@Transactional
	@Override
	public void deleteWithReplies(Long bno) {
		//삭제기능 구현, 트랜잭션 추가
		
		//댓글부터 삭제
		replyRepository.deleteByBno(bno);
		
		//댓글삭제후 게시글 삭제
		boardRepository.deleteById(bno);
			
	}
	
	//게시글 제목, 내용 수정
	@Override
	@Transactional
	public void modify(BoardDTO boardDTO) {
		
		Board board = boardRepository.getById(boardDTO.getBno());
		
		board.changeTitle(boardDTO.getTitle());
		
		board.changeContent(boardDTO.getContent());
		
		boardRepository.save(board);
		
	}
	
	
	
	

}
