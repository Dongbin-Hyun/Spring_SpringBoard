package kr.ac.kopo.ctc.spring.board.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;


import kr.ac.kopo.ctc.spring.board.service.ReplyService;
import kr.ac.kopo.ctc.spring.board.DTO.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/replies/")
@Log4j2
@RequiredArgsConstructor
public class ReplyController {
	
	private final ReplyService replyService;
	
	//@GetMapping & ResponseEntity & @PathVariable
	//RestController의 경우 모든 메서드의 리턴 타입은 기본적으로 JSON
	//메서드의 반환 타입은 ResposeEntity라는 객체 이용 -> Http의 상태 코드 등을 같이 전달 가능
	//@GetMapping()에 URL의 일부를 {}로 묶은 변수 이용 -> @PathVariable 처리
	//ex) replies/board/40 
	@GetMapping(value = "/board/{bno}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReplyDTO>> getListByBoard(@PathVariable("bno") Long bno) {
		
		log.info("bno : " + bno);
		
		return new ResponseEntity<>(replyService.getList(bno), HttpStatus.OK);
	}
	
	//댓글 등록 처리
	//@RequestBody는 JSON으로 들어오는 데이터를 자동으로 해당 타입의 객체로 매핑해주는 역할 담당
	//따라서 개발 시 별도의 처리 없이 도 JSON 데이터를 특정 타입의 객체로 변환해서 처리할 수 있음
	@PostMapping("")
	public ResponseEntity<Long> create(@RequestBody ReplyDTO replyDTO) {
			
		log.info(replyDTO);		
		
		Long rno = replyService.create(replyDTO);
		
		return new ResponseEntity<>(rno, HttpStatus.OK);
	}
	
	//Delete 방식을 전달받았음 -> @DeleteMapping으로 처리
	@DeleteMapping("/{rno}")
    public ResponseEntity<String> remove(@PathVariable("rno") Long rno) {

        log.info("RNO:" + rno );

        replyService.delete(rno);

        return new ResponseEntity<>("success", HttpStatus.OK);

    }
	
	//Put 방식으로 전달받음 -> @PutMapping으로 처리
	@PutMapping("/{rno}")
    public ResponseEntity<String> modify(@RequestBody ReplyDTO replyDTO) {

        log.info(replyDTO);

        replyService.modify(replyDTO);

        return new ResponseEntity<>("success", HttpStatus.OK);
	
	}

}
