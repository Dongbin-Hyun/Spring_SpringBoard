package kr.ac.kopo.ctc.spring.board.repository;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import kr.ac.kopo.ctc.spring.board.domain.*;
import kr.ac.kopo.ctc.spring.board.repository.search.SearchBoardRepository;


public interface BoardRepository extends JpaRepository<Board, Long>, SearchBoardRepository {
	
	//연관관계가 있는 경우
	//게시글의 정보와 함께 댓글의 수를 같이 가져오기 위함
	@Query("select b, w from Board b left join b.writer w where b.bno =:bno")
	Object getBoardWithWriter(@Param("bno") Long bno);
	
	//연관관계가 없는 경우 "on"
	//특정 게시물과 해당 게시물에 속한 댓글들을 조회해야하는 상황
	@Query("SELECT b, r FROM Board b LEFT JOIN Reply r ON r.board = b WHERE b.bno = :bno")
	List<Object[]> getBoardWithReply(@Param("bno") Long bno);
	
	//목록화면에 필요
	@Query(value = "SELECT b, w, count(r) " +
					" FROM Board b " +
					" LEFT JOIN b.writer w " +
					" LEFT JOIN Reply r ON r.board = b " +
					" GROUP BY b",
					countQuery = "SELECT count(b) FROM Board b")
	Page<Object[]> getBoardWithReplyCount(Pageable pagebale);
	//목록화면에 필요한 데이터
	
	@Query("SELECT b, w, count(r) " +
					" FROM Board b LEFT JOIN b.writer w " + 
					" LEFT OUTER JOIN Reply r ON r.board = b" + 
					" WHERE b.bno = :bno")
	Object getBoardByBno(@Param("bno") Long bno);
	
	Board getById(@Param("bno") Long bno);
	
	
	
}
